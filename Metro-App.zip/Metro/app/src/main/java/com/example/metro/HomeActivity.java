package com.example.metro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private static final String[] ITEMS = {
            // Stations between Chennai Central to St Thomas Mount
            "MGR Central (Chennai Central)",
            "Egmore", "Nehru Park", "Kilpauk Medical College", "Pachaiyappa College", "Shenoy Nagar",
            "Anna Nagar East", "Anna Nagar Tower", "Thirumangalam", "Koyambedu", "CMBT", "Arumbakkam",
            "Vadapalani", "Ashok Nagar", "Ekkattuthangal", "Arignar Anna Alandur", "St Thomas Mount"
    };
    private static final String[] ITEMS1 = {
            // Stations between Chennai Central to St Thomas Mount
            "MGR Central (Chennai Central)",
            "Egmore", "Nehru Park", "Kilpauk Medical College", "Pachaiyappa College", "Shenoy Nagar",
            "Anna Nagar East", "Anna Nagar Tower", "Thirumangalam", "Koyambedu", "CMBT", "Arumbakkam",
            "Vadapalani", "Ashok Nagar", "Ekkattuthangal", "Arignar Anna Alandur", "St Thomas Mount"
    };

    private static final String[] ITEMS2 = {
            // Select Journey
            "Single Journey"
    };

    private EditText quantityEditText,et3;
    private Button incrementButton, decrementButton, nextButton;
    private AutoCompleteTextView autoCompleteTextView1, autoCompleteTextView2, autoCompleteTextView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        autoCompleteTextView1 = findViewById(R.id.et1);
        autoCompleteTextView2 = findViewById(R.id.et2);
        autoCompleteTextView3 = findViewById(R.id.et4);

        quantityEditText = findViewById(R.id.quantityEditText);
        incrementButton = findViewById(R.id.incrementButton);
        decrementButton = findViewById(R.id.decrementButton);
        nextButton = findViewById(R.id.nextbutton);
        et3 = findViewById(R.id.et3);


        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementQuantity();
            }
        });

        decrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementQuantity();
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input1 = autoCompleteTextView1.getText().toString().trim();
                String input2 = autoCompleteTextView2.getText().toString().trim();
                String input3 = autoCompleteTextView3.getText().toString().trim();
                String input4 = et3.getText().toString().trim();

                int quantity = Integer.parseInt(quantityEditText.getText().toString());

                // Saving input1 to SharedPreferences
                saveToSharedPreferences("autoCompleteTextView1", input1);
                saveToSharedPreferences("autoCompleteTextView2", input2);
                saveToSharedPreferences("autoCompleteTextView3", input3);
                saveQuantityToSharedPreferences("quantityEditText", quantity);

                if (input1.isEmpty() || input2.isEmpty() || input3.isEmpty() || input4.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(HomeActivity.this, ReceiptActivity.class);
                    intent.putExtra("quantity", quantity);
                    intent.putExtra("origin", input1);
                    intent.putExtra("destination", input2);
                    startActivity(intent);
                }
            }
        });

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, ITEMS);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, ITEMS1);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, ITEMS2);
        autoCompleteTextView1.setAdapter(adapter1);
        autoCompleteTextView2.setAdapter(adapter2);
        autoCompleteTextView3.setAdapter(adapter3);
    }//oncreate close
    private void incrementQuantity() {
        // Increment quantity
        int quantity = Integer.parseInt(quantityEditText.getText().toString());
        quantity++;
        quantityEditText.setText(String.valueOf(quantity));
    }

    private void decrementQuantity() {
        // Decrement quantity
        int quantity = Integer.parseInt(quantityEditText.getText().toString());
        if (quantity > 1) {
            quantity--;
            quantityEditText.setText(String.valueOf(quantity));
        } else {
            Toast.makeText(this, "Quantity cannot be less than 1", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to save data to SharedPreferences
    private void saveToSharedPreferences(String key, String value) {
        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }
    private void saveQuantityToSharedPreferences(String key, int quantity) {
        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(key, quantity);
        editor.apply();
    }
}
