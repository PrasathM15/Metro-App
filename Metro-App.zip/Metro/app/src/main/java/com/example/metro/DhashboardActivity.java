package com.example.metro;

import static com.example.metro.R.id.nextbutton1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DhashboardActivity extends AppCompatActivity {
    private Button nextbutton, nextbutton1,nextbutton2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dhashboard);

        nextbutton=findViewById(R.id.nextbutton);
        nextbutton1=findViewById(R.id.nextbutton1);
        nextbutton2=findViewById(R.id.nextbutton2);

        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextActivity();
            }
        });

        nextbutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextActivity1();
            }
        });

        nextbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextActivity2();
            }
        });

    }

    private void navigateToNextActivity() {
        Intent intent = new Intent(DhashboardActivity.this, HomeActivity.class);
        startActivity(intent);
    }
    private void navigateToNextActivity1() {
        Intent intent1 = new Intent(DhashboardActivity.this, TimeActivity.class);
        startActivity(intent1);
    }
    private void navigateToNextActivity2() {
        Intent intent2 = new Intent(DhashboardActivity.this, MapActivity.class);
        startActivity(intent2);
    }
}