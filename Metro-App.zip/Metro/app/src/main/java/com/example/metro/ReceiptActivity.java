package com.example.metro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ReceiptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        Intent intent = getIntent();

        int quantity = intent.getIntExtra("quantity", 1); // Default quantity is 1

        String origin = intent.getStringExtra("origin");
        String destination = intent.getStringExtra("destination");

        TextView fromm = findViewById(R.id.fromm);
        TextView too = findViewById(R.id.too);
        fromm.setText(origin);
        too.setText(destination);

        // Calculate fare based on origin and destination
        int fare = calculateFare(origin, destination);

        TextView quantityTextView = findViewById(R.id.quantityTextView);
        TextView quantityTextView1 = findViewById(R.id.itemPriceTextView);
        quantityTextView.setText(quantity + " ticket");
        quantityTextView1.setText("Price: ₹" + (quantity * fare) + ".00");

        // Get current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());

        // Set current date to TextView
        TextView currentDateTextView = findViewById(R.id.currentDateTextView);
        currentDateTextView.setText("" + currentDate);

        // Get current time
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = timeFormat.format(calendar1.getTime());

        // Set current time to TextView
        TextView currentTimeTextView = findViewById(R.id.currentTimeTextView);
        currentTimeTextView.setText("" + currentTime);


    }//oncreate close

    private int calculateFare(String origin, String destination) {
        if (origin.equals("MGR Central (Chennai Central)") && destination.equals("Anna Nagar Tower")||
                origin.equals("Pachaiyappa College") && destination.equals("Vadapalani") ||
                origin.equals("Vadapalani") && destination.equals("Pachaiyappa College") ||
                origin.equals("Anna Nagar Tower") && destination.equals("St Thomas Mount")||
                origin.equals("St Thomas Mount") && destination.equals("Anna Nagar Tower")||
                origin.equals("Anna Nagar Tower") && destination.equals("MGR Central (Chennai Central)")) {
            return 35;
        }else if (origin.equals("MGR Central (Chennai Central)") && destination.equals("Kilpauk Medical College")||
                origin.equals("Kilpauk Medical College") && destination.equals("Anna Nagar Tower") ||
                origin.equals("Anna Nagar Tower") && destination.equals("Vadapalani")||
                origin.equals("Vadapalani") && destination.equals("St Thomas Mount")||
                origin.equals("Kilpauk Medical College") && destination.equals("MGR Central (Chennai Central)")||
                origin.equals("Anna Nagar Tower") && destination.equals("Kilpauk Medical College")||
                origin.equals("Vadapalani") && destination.equals("Anna Nagar Tower")||
                origin.equals("St Thomas Mount") && destination.equals("Vadapalani")) {
            return 20;
        }else {
            return 50; // Assuming one to another end so fare is 50rs
        }
    }
    public void goToNextPage(View view) {
        Intent intent = new Intent(ReceiptActivity.this, OptionActivity.class);
        startActivity(intent);
    }

    }//main close