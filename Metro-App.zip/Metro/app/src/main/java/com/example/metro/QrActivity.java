package com.example.metro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class QrActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        // Retrieve from SharedPreferences
        String originStation = getFromSharedPreferences("autoCompleteTextView1");
        String destinationStation = getFromSharedPreferences("autoCompleteTextView2");
        String tickettype = getFromSharedPreferences("autoCompleteTextView3");
        int quantity = getQuantityFromSharedPreferences("quantityEditText");

        // Set to TextView
        TextView originTextView = findViewById(R.id.fromm);
        TextView destinationTextView = findViewById(R.id.too);
        TextView ticketTextView = findViewById(R.id.tick);
        TextView quantityTextView = findViewById(R.id.quantityTextView);

        //assigning
        originTextView.setText(originStation);
        destinationTextView.setText(destinationStation);
        ticketTextView.setText(tickettype);
        quantityTextView.setText(String.valueOf(quantity));

        // Set current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());
        TextView currentDateTextView = findViewById(R.id.currentDateTextView);
        currentDateTextView.setText(currentDate);

        // Set current time
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = timeFormat.format(calendar1.getTime());
        TextView currentTimeTextView = findViewById(R.id.currentTimeTextView);
        currentTimeTextView.setText(currentTime);

        // Button to navigate to DashboardActivity
        Button nextButton = findViewById(R.id.button8);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QrActivity.this, DhashboardActivity.class);
                startActivity(intent);
            }
        });

        // Button to simulate downloading a QR ticket
        Button downloadButton = findViewById(R.id.button9);
        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show a toast message
                Toast.makeText(QrActivity.this, "QR ticket downloaded successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to retrieve data from SharedPreferences
    private String getFromSharedPreferences(String key) {
        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        return sharedPref.getString(key, "");
    }
    private int getQuantityFromSharedPreferences(String key) {
        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        return sharedPref.getInt(key, 0);
    }
}
